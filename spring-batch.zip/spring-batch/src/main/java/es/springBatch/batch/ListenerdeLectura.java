package es.springBatch.batch;

import org.springframework.batch.core.ItemReadListener;
import es.springBatch.batch.model.Student;

public class ListenerdeLectura implements ItemReadListener<Student>{
	public void beforeRead() {
		System.out.println("Before reading an item");		
	}

	public void afterRead(Student item) {
		System.out.println("After reading an item: "+ item.toString());		
	}

	public void onReadError(Exception ex) {
		System.out.println("Error occurred while reading an item!");		
	}
	
}
