package es.springBatch.batch.processor;

import org.springframework.batch.item.ItemProcessor;

import es.springBatch.batch.model.Student;

public class StudentItemProcessor implements ItemProcessor<Student, Student>{

	@Override
	public Student process(Student student) throws Exception {
		System.out.println("Processing: " + student);
		final String initCapFirstName = student.getFirstName().substring(0, 1).toUpperCase()
				+ student.getFirstName().substring(1);
		final String initCapLastName = student.getLastName().substring(0, 1).toUpperCase()
				+ student.getLastName().substring(1);
		Student transformedPerson = new Student();
		transformedPerson.setFirstName(initCapFirstName);
		transformedPerson.setLastName(initCapLastName);
		transformedPerson.setSchool(student.getSchool());
		transformedPerson.setRollNumber(student.getRollNumber());
		return transformedPerson;
	}
}
